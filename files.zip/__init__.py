"""
ceds64 — Python wrapper for the CED SON64 library (ceds64int.dll).

Usage
-----
    import ceds64

    # Point to your CEDS64ML folder containing x64/ or x86/ subdirectory
    ceds64.load_lib(r"C:\\path\\to\\CEDS64ML")

    fhand = ceds64.open(r"C:\\data\\recording.smr")
    tb = ceds64.time_base(fhand)
    ...
    ceds64.close(fhand)
"""

from .ceds64 import *          # noqa: F401,F403
from .ceds64 import load_lib   # explicit for IDE auto-complete
